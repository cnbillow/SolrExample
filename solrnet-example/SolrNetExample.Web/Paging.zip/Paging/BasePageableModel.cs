﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace SolrNetExample.Web.Paging
{
    /// <summary>
    /// 基础可分页对象模型。
    /// </summary>
    public class BasePageableModel : IPageableModel
    {

        public BasePageableModel()
        {

        }

        #region Methods

        public IEnumerator GetEnumerator()
        {
            return new List<string>().GetEnumerator();
        }

        /// <summary>
        /// 加载分页项目列表。
        /// </summary>
        /// <typeparam name="T">指定的对象类型。</typeparam>
        /// <param name="pagedList">分页项目列表。</param>
        public virtual void LoadPagedList<T>(IPagedList<T> pagedList)
        {
            FirstItem = (pagedList.PageIndex * pagedList.PageSize) + 1;
            HasNextPage = pagedList.HasNextPage;
            HasPreviousPage = pagedList.HasPreviousPage;
            LastItem = Math.Min(pagedList.TotalCount, ((pagedList.PageIndex * pagedList.PageSize) + pagedList.PageSize));
            PageNumber = pagedList.PageIndex + 1;
            PageSize = pagedList.PageSize;
            TotalItems = pagedList.TotalCount;
            TotalPages = pagedList.TotalPages;
        }

        #endregion

        #region Properties

        /// <summary>
        /// 获取或设置是否有在当前页面之后的页面。
        /// </summary>
        public bool HasNextPage { get; set; }

        /// <summary>
        /// 获取或设置是否有在当前页面之前的页面。
        /// </summary>
        public bool HasPreviousPage { get; set; }

        /// <summary>
        /// 获取或设置当前页面的第一个项目的索引。
        /// </summary>
        public int FirstItem { get; set; }

        /// <summary>
        /// 获取或设置当前页面的最后一个项目的索引。
        /// </summary>
        public int LastItem { get; set; }

        /// <summary>
        /// 获取或设置当前页面的索引（从 0 开始）。
        /// </summary>
        public int PageIndex
        {
            get
            {
                if (PageNumber > 0)
                    return PageNumber - 1;
                else
                    return 0;
            }
        }
        /// <summary>
        /// 获取或设置当前页面的页码（从 1 开始）。
        /// </summary>
        public int PageNumber { get; set; }

        /// <summary>
        /// 获取或设置当前页面显示的项目数量。
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// 获取或设置项目的记录总数。
        /// </summary>
        public int TotalItems { get; set; }

        /// <summary>
        /// 获取或设置页面的记录总数。
        /// </summary>
        public int TotalPages { get; set; }

        #endregion
    }
}
