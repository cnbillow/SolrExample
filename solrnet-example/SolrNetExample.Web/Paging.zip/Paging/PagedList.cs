﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace SolrNetExample.Web.Paging
{
    /// <summary>
    /// 表示一个分页列表对象。
    /// </summary>
    /// <typeparam name="T">分页的实体对象。</typeparam>
    [Serializable, DataContract(IsReference = true)]
    public class PagedList<T> : List<T>, IPagedList<T>, ISerializable
    {
        /// <summary>
        /// 初始化一个包含支持查询的数据源的 <see cref="PagedList"/> 类的新实例。
        /// </summary>
        /// <param name="source">指定的数据源。</param>
        /// <param name="pageIndex">指定的分页索引。</param>
        /// <param name="pageSize">指定的分页大小。</param>
        public PagedList(IQueryable<T> source, int pageIndex, int pageSize)
        {
            int total = source.Count();
            //this.TotalCount = total;
            TotalPages = total / pageSize;

            if (total % pageSize > 0)
                TotalPages++;

            PageSize = pageSize;
            PageIndex = pageIndex;
            AddRange(source.ToList());
            //this.AddRange(source.Skip(pageIndex * pageSize).Take(pageSize).ToList());
        }

        /// <summary>
        /// 初始化一个包含支持索引的数据源的 <see cref="PagedList"/> 类的新实例。
        /// </summary>
        /// <param name="source">指定的数据源。</param>
        /// <param name="pageIndex">指定的分页索引。</param>
        /// <param name="pageSize">指定的分页大小。</param>
        public PagedList(IList<T> source, int pageIndex, int pageSize, int totalCount)
        {
            TotalCount = totalCount;
            TotalPages = TotalCount / pageSize;

            if (TotalCount % pageSize > 0)
                TotalPages++;

            PageSize = pageSize;
            PageIndex = pageIndex;
            AddRange(source.ToList());
            //this.AddRange(source.Skip(pageIndex * pageSize).Take(pageSize).ToList());
        }

        /// <summary>
        /// 初始化一个包含支持枚举的数据源的 <see cref="PagedList"/> 类的新实例。
        /// </summary>
        /// <param name="source">指定的数据源。</param>
        /// <param name="pageIndex">指定的分页索引。</param>
        /// <param name="pageSize">指定的分页大小。</param>
        /// <param name="totalCount">记录总数。</param>
        public PagedList(IEnumerable<T> source, int pageIndex, int pageSize, int totalCount)
        {
            TotalCount = totalCount;
            TotalPages = TotalCount / pageSize;

            if (TotalCount % pageSize > 0)
                TotalPages++;

            PageSize = pageSize;
            PageIndex = pageIndex;
            AddRange(source);
        }

        /// <summary>
        /// 当前页面的索引（从 0 开始）。
        /// </summary>
        [DataMember(Name = "PageIndex", IsRequired = true)]
        public int PageIndex { get; set; }
        /// <summary>
        /// 当前页面显示的项目数量。
        /// </summary>
        [DataMember(Name = "PageSize", IsRequired = true)]
        public int PageSize { get; set; }
        /// <summary>
        /// 项目的记录总数。
        /// </summary>
        [DataMember(Name = "TotalCount", IsRequired = true)]
        public int TotalCount { get; set; }
        /// <summary>
        /// 页面的记录总数。
        /// </summary>
        [DataMember(Name = "TotalPages", IsRequired = true)]
        public int TotalPages { get; private set; }

        /// <summary>
        /// 是否有在当前页面之前的页面。
        /// </summary>
        [JsonProperty]
        public bool HasPreviousPage
        {
            get { return (PageIndex > 0); }
        }

        /// <summary>
        /// 是否有在当前页面之后的页面。
        /// </summary>
        [JsonProperty]
        public bool HasNextPage
        {
            get { return (PageIndex + 1 < TotalPages); }
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            throw new NotImplementedException();
        }
    }
}
