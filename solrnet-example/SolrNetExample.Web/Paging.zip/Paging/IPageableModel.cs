﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolrNetExample.Web.Paging
{
    /// <summary>
    /// 定义一个可分页的对象模型。
    /// </summary>
    public interface IPageableModel : IEnumerable
    {
        /// <summary>
        /// 当前页面的索引（从 0 开始）。
        /// </summary>
        int PageIndex { get; }
        /// <summary>
        /// 当前页码（从 1 开始）。
        /// </summary>
        int PageNumber { get; }
        /// <summary>
        /// 当前页面显示的项目数量。
        /// </summary>
        int PageSize { get; }
        /// <summary>
        /// 项目的记录总数。
        /// </summary>
        int TotalItems { get; }
        /// <summary>
        /// 页面的记录总数。
        /// </summary>
        int TotalPages { get; }
        /// <summary>
        /// 当前页面的第一个项目的索引。
        /// </summary>
        int FirstItem { get; }
        /// <summary>
        /// 当前页面的最后一个项目的索引。
        /// </summary>
        int LastItem { get; }
        /// <summary>
        /// 是否有在当前页面之前的页面。
        /// </summary>
        bool HasPreviousPage { get; }
        /// <summary>
        /// 是否有在当前页面之后的页面。
        /// </summary>
        bool HasNextPage { get; }
    }
}
